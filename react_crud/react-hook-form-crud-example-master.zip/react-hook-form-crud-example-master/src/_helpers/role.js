export const Role = {
    Admin: 'Admin',
    User: 'User'    
};